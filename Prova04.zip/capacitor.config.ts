import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'io.ionic.starter',
  appName: 'ATIVIDADE04_20242007460',
  webDir: 'www'
};

export default config;
